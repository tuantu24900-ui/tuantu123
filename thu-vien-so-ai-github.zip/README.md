# 🧠 Thư viện số AI — Tổng quan Trí tuệ Nhân tạo (8 Chương)

Trang web tài liệu học tập tương tác gồm 8 chương cốt lõi, hỗ trợ điều hướng theo URL hash (`#trang-chu`, `#chuong-1` ... `#chuong-8`), tìm kiếm nhanh, chuyển giao diện Sáng/Tối, lưu ghi chú cá nhân và danh sách link tham khảo ngay trên trình duyệt (`localStorage`).

## Nội dung 8 chương
1. **Chương 1:** Bối cảnh CMCN 4.0, CNTT 4.0 & Chuyển đổi số
2. **Chương 2:** Kiến trúc Phần cứng & Nguyên lý máy tính
3. **Chương 3:** Hệ điều hành (OS) & Quản lý tài nguyên
4. **Chương 4:** Phần mềm ứng dụng, Ảo hóa & Điện toán đám mây
5. **Chương 5:** Mạng máy tính, Internet & Hệ sinh thái IoT
6. **Chương 6:** Tư duy tính toán, Thuật toán & Tự động hóa
7. **Chương 7:** Trí tuệ nhân tạo (AI), Dữ liệu lớn & Prompt
8. **Chương 8:** An toàn thông tin, Bảo vệ dữ liệu & Đạo đức AI

## Cách đưa lên GitHub Pages để có đường link web
1. Tạo một Repository mới trên GitHub (ví dụ: `thu-vien-so-ai`).
2. Tải lên toàn bộ các file trong gói này (`index.html` và `README.md`).
3. Vào **Settings → Pages → Build and deployment → Source: Deploy from a branch**, chọn nhánh `main` và thư mục `/ (root)` rồi bấm **Save**.
4. Sau khoảng 1 phút, GitHub sẽ cấp đường link dạng `https://<ten-tai-khoan>.github.io/thu-vien-so-ai/#chuong-1`.
